import axios from 'axios';

class PterodactylService {
  constructor() {
    this.timeout = 30000;
  }

  // Normalize a panel URL: trim, ensure protocol, strip trailing slashes
  normalizeUrl(panelUrl) {
    if (!panelUrl) return '';
    let url = String(panelUrl).trim();
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`;
    return url.replace(/\/+$/, '');
  }

  // Test connection to Pterodactyl panel
  async testConnection(panelUrl, apiKey) {
    const url = this.normalizeUrl(panelUrl);
    if (!url) return { success: false, error: 'Panel URL is required' };
    if (!apiKey) return { success: false, error: 'Application API Key is required' };

    const testPath = '/api/application/users?per_page=1';
    try {
      const response = await axios.get(`${url}${testPath}`, {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          Accept: 'Application/vnd.pterodactyl.v1+json',
        },
        timeout: this.timeout,
      });
      return { success: true, status: response.status };
    } catch (error) {
      if (error.code === 'ECONNREFUSED') {
        return { success: false, error: `Connection refused. Check the URL (${url}) is correct and the panel is running.` };
      }
      if (error.code === 'ENOTFOUND' || error.code === 'EAI_AGAIN') {
        return { success: false, error: `Host not found: ${url}. Check the domain is correct.` };
      }
      if (error.code === 'ECONNABORTED') {
        return { success: false, error: `Request timed out. Check that ${url} is reachable and HTTPS is correct.` };
      }
      if (error.response?.status === 404) {
        return { success: false, error: `Panel returned 404 on ${url}${testPath}. This URL does not look like a Pterodactyl panel — check it (e.g. https://panel.yourdomain.com, no trailing path).` };
      }
      if (error.response?.status === 401 || error.response?.status === 403) {
        return { success: false, error: 'Authentication failed. Check your Application API Key.' };
      }
      if (error.response?.status) {
        return { success: false, error: `Panel responded with HTTP ${error.response.status}. Check the URL ${url} is correct.` };
      }
      return { success: false, error: error.message };
    }
  }

  // Create a new user on Pterodactyl
  async createUser(panelUrl, apiKey, userData) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.post(
        `${url}/api/application/users`,
        {
          email: userData.email,
          username: userData.username,
          first_name: userData.firstName || 'SHP',
          last_name: userData.lastName || 'User',
          ...(userData.password ? { password: userData.password } : {}),
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      return response.data?.attributes || response.data?.data?.attributes || response.data?.data || response.data;
    } catch (error) {
      throw new Error(`Failed to create Pterodactyl user: ${error.response?.data?.errors?.[0]?.code || error.message}`);
    }
  }

  // Get user by email
  async getUserByEmail(panelUrl, apiKey, email) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.get(`${url}/api/application/users`, {
        params: { 'filter[email]': email },
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          Accept: 'Application/vnd.pterodactyl.v1+json',
        },
      });
      const list = response.data?.data || [];
      return list?.[0] || null;
    } catch (error) {
      if (error.response?.status === 404) return null;
      throw new Error(`Failed to get user: ${error.message}`);
    }
  }

  // Create a new server
  async createServer(panelUrl, apiKey, serverData) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.post(
        `${url}/api/application/servers`,
        {
          name: serverData.name,
          user: serverData.userId,
          nest: serverData.nestId,
          egg: serverData.eggId,
          docker_image: serverData.dockerImage,
          startup: serverData.startup,
          environment: serverData.environment,
          limits: {
            memory: serverData.memory,
            swap: serverData.swap || 0,
            disk: serverData.disk,
            io: serverData.io || 500,
            cpu: serverData.cpu,
          },
          feature_limits: {
            databases: serverData.databases || 0,
            allocations: serverData.allocations || 1,
            backups: serverData.backups || 0,
          },
          allocation: {
            default: Number(serverData.allocationId),
            additional: serverData.additionalAllocationIds || [],
          },
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      return response.data?.attributes || response.data?.data?.attributes || response.data?.data || response.data;
    } catch (error) {
      throw new Error(
        `Failed to create server (allocation.default=${serverData.allocationId}): ${
          JSON.stringify(error.response?.data) || error.message
        }`
      );
    }
  }

  // Get server details
  async getServerInfo(panelUrl, apiKey, serverId) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.get(
        `${url}/api/application/servers/${serverId}`,
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get server info: ${error.message}`);
    }
  }

  // Delete a server
  async deleteServer(panelUrl, apiKey, serverId) {
    const url = this.normalizeUrl(panelUrl);
    try {
      await axios.delete(`${url}/api/application/servers/${serverId}`, {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          Accept: 'Application/vnd.pterodactyl.v1+json',
        },
      });
      return { success: true };
    } catch (error) {
      throw new Error(`Failed to delete server: ${error.message}`);
    }
  }

  // Suspend a server
  async suspendServer(panelUrl, apiKey, serverId) {
    const url = this.normalizeUrl(panelUrl);
    try {
      await axios.post(
        `${url}/api/application/servers/${serverId}/suspend`,
        {},
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      return { success: true };
    } catch (error) {
      throw new Error(`Failed to suspend server: ${error.message}`);
    }
  }

  // Unsuspend a server
  async unsuspendServer(panelUrl, apiKey, serverId) {
    const url = this.normalizeUrl(panelUrl);
    try {
      await axios.post(
        `${url}/api/application/servers/${serverId}/unsuspend`,
        {},
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      return { success: true };
    } catch (error) {
      throw new Error(`Failed to unsuspend server: ${error.message}`);
    }
  }

  // Send power action (start, stop, restart, kill)
  async sendPowerAction(panelUrl, apiKey, serverId, action) {
    const url = this.normalizeUrl(panelUrl);
    try {
      await axios.post(
        `${url}/api/application/servers/${serverId}/power`,
        { signal: action },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      return { success: true };
    } catch (error) {
      throw new Error(`Failed to send power action: ${error.message}`);
    }
  }

  // Get server resources usage
  async getServerResources(panelUrl, apiKey, serverId) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.get(
        `${url}/api/application/servers/${serverId}/resources`,
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get server resources: ${error.message}`);
    }
  }

  // Update server build/limits
  async updateServer(panelUrl, apiKey, serverId, limits) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.patch(
        `${url}/api/application/servers/${serverId}/build`,
        {
          limits: {
            memory: limits.memory,
            swap: limits.swap || 0,
            disk: limits.disk,
            io: limits.io || 500,
            cpu: limits.cpu,
          },
          feature_limits: {
            databases: limits.databases || 0,
            allocations: limits.allocations || 1,
            backups: limits.backups || 0,
          },
        },
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      return response.data;
    } catch (error) {
      throw new Error(`Failed to update server: ${JSON.stringify(error.response?.data) || error.message}`);
    }
  }

  // Get current state of a server (running/stopped/starting/stopping)
  async getServerState(panelUrl, apiKey, serverId) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.get(
        `${url}/api/application/servers/${serverId}`,
        {
          headers: {
            Authorization: `Bearer ${apiKey}`,
            'Content-Type': 'application/json',
            Accept: 'Application/vnd.pterodactyl.v1+json',
          },
        }
      );
      const attr = response.data?.attributes || response.data?.data?.attributes || response.data;
      return { state: attr?.status || null, ...attr };
    } catch (error) {
      throw new Error(`Failed to get server state: ${error.message}`);
    }
  }

  // Get all nodes
  async getNodes(panelUrl, apiKey) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.get(`${url}/api/application/nodes`, {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          Accept: 'Application/vnd.pterodactyl.v1+json',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get nodes: ${error.message}`);
    }
  }

  // Get all eggs (across all nests). Pterodactyl has no global /eggs route,
  // so we page through nests and collect their eggs.
  async getEggs(panelUrl, apiKey, nodeId = null) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const headers = {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        Accept: 'Application/vnd.pterodactyl.v1+json',
      };

      if (nodeId) {
        const res = await axios.get(`${url}/api/application/nodes/${nodeId}/eggs`, {
          params: { include: 'variables', per_page: 100 },
          headers,
        });
        return res.data;
      }

      // Fetch all nests first
      const nestsRes = await axios.get(`${url}/api/application/nests`, {
        params: { per_page: 100 },
        headers,
      });
      const nests = nestsRes.data?.data || [];

      const eggs = [];
      for (const nest of nests) {
        const nestId = nest?.id ?? nest?.attributes?.id;
        if (!nestId) continue;
        try {
          const eggsRes = await axios.get(`${url}/api/application/nests/${nestId}/eggs`, {
            params: { include: 'variables', per_page: 100 },
            headers,
          });
          const list = eggsRes.data?.data || [];
          for (const egg of list) {
            const attr = egg?.attributes || egg;
            if (attr && !attr.relationships?.nest) {
              attr.relationships = { nest: { attributes: { id: nestId } } };
            }
            eggs.push(egg);
          }
        } catch {
          // skip nests we cannot read
        }
      }

      return { object: 'list', data: eggs };
    } catch (error) {
      throw new Error(
        error.response?.status === 404
          ? `Failed to get eggs: the Pterodactyl API returned 404. Your App API key may not have permission to read nests/eggs (Admin → Application API → assign nests & eggs read), or the panel URL is wrong.`
          : `Failed to get eggs: ${error.message}`
      );
    }
  }

  // Get locations
  async getLocations(panelUrl, apiKey) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.get(`${url}/api/application/locations`, {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          Accept: 'Application/vnd.pterodactyl.v1+json',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get locations: ${error.message}`);
    }
  }

  // Get allocations for a node
  async getAllocations(panelUrl, apiKey, nodeId) {
    const url = this.normalizeUrl(panelUrl);
    try {
      const response = await axios.get(`${url}/api/application/nodes/${nodeId}/allocations`, {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          Accept: 'Application/vnd.pterodactyl.v1+json',
        },
      });
      return response.data;
    } catch (error) {
      throw new Error(`Failed to get allocations: ${error.message}`);
    }
  }

  // Change a server's primary allocation (port). The new allocation must be
  // free. Pterodactyl sets `default` as the new primary and keeps `additional`.
  async setPrimaryAllocation(panelUrl, apiKey, serverId, newAllocationId, additional) {
    const url = this.normalizeUrl(panelUrl);
    const headers = {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'Application/vnd.pterodactyl.v1+json',
    };
    const response = await axios.patch(
      `${url}/api/application/servers/${serverId}/allocation`,
      {
        default: Number(newAllocationId),
        additional: (additional || []).map((a) => Number(a)),
      },
      { headers }
    );
    return response.data;
  }

  // Get the allocations currently assigned to a server
  async getServerAllocations(panelUrl, apiKey, serverId) {
    const url = this.normalizeUrl(panelUrl);
    const headers = {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'Application/vnd.pterodactyl.v1+json',
    };
    const response = await axios.get(`${url}/api/application/servers/${serverId}/allocations`, { headers });
    return response.data;
  }

  // Get a single egg by id across all nests (with variables), or null.
  // Returns { nestId, variables: [...] } where each variable has
  // { env, name, description, default_value, rules, options }.
  async getEggConfig(panelUrl, apiKey, eggId) {
    const url = this.normalizeUrl(panelUrl);
    const headers = {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'Application/vnd.pterodactyl.v1+json',
    };

    const nestsRes = await axios.get(`${url}/api/application/nests`, { params: { per_page: 100 }, headers });
    const nests = nestsRes.data?.data || [];

    for (const nest of nests) {
      const nestId = nest?.id ?? nest?.attributes?.id;
      if (!nestId) continue;
      let eggs;
      try {
        const res = await axios.get(`${url}/api/application/nests/${nestId}/eggs`, {
          params: { include: 'variables', per_page: 100 },
          headers,
        });
        eggs = res.data?.data || [];
      } catch {
        continue;
      }
      const egg = eggs.find((e) => String(e?.id ?? e?.attributes?.id) === String(eggId));
      if (!egg) continue;
      const attr = egg.attributes || egg;
      const vars = (attr.relationships?.variables?.data || []).map((v) => {
        const a = v.attributes || v;
        let options = a.options;
        if (typeof options === 'string') {
          try {
            options = JSON.parse(options);
          } catch {
            options = options.split(',').map((s) => s.trim());
          }
        }
        if (!Array.isArray(options)) options = null;
        return {
          env: a.env_variable,
          name: a.name,
          description: a.description,
          defaultValue: a.default_value,
          required: String(a.rules || '').includes('required'),
          options,
          rules: a.rules,
        };
      });
      return { nestId, eggId: String(attr.id ?? eggId), eggName: attr.name, variables: vars };
    }
    return null;
  }

  // Return a list of every free allocation across all nodes.
  // Each entry: { allocationId, nodeId, ip, port }
  async getFreeAllocations(panelUrl, apiKey) {
    const url = this.normalizeUrl(panelUrl);
    const headers = {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      Accept: 'Application/vnd.pterodactyl.v1+json',
    };

    const nodesRes = await axios.get(`${url}/api/application/nodes`, {
      params: { per_page: 100 },
      headers,
    });
    const nodes = nodesRes.data?.data || [];

    const free = [];
    for (const node of nodes) {
      const nodeId = node?.id ?? node?.attributes?.id;
      if (!nodeId) continue;
      let allocs;
      try {
        const res = await axios.get(`${url}/api/application/nodes/${nodeId}/allocations`, {
          params: { per_page: 500 },
          headers,
        });
        allocs = res.data?.data || [];
      } catch {
        continue;
      }
      for (const a of allocs) {
        const attr = a?.attributes || a;
        if (attr.assigned || attr.assigned_to) continue;
        free.push({
          allocationId: attr.id,
          nodeId,
          node: node.attributes?.name ?? node.name ?? String(nodeId),
          ip: attr.ip,
          port: attr.port,
          alias: attr.alias,
          label: `${attr.ip}:${attr.port} (node ${nodeId})`,
        });
      }
    }
    return free;
  }
}

export const pterodactylService = new PterodactylService();
